/*
 * 
 * Name: Peter Huang
 * Student Number: 300021511
 * node class will store the rank and node number of the individual 
 * elements of the graph
 * 
 * 
*/
public class Node {
	public double pageRank;
	public int nodeNumber;
	
	public Node(int n) {
		this.pageRank = 1.0;

		this.nodeNumber = n;
	}
	
	public void setPageRank(double n){
		pageRank = n;
	}
	

	public double getPageRank(){
		return pageRank;
	}
	
	
	public int getNodeNumber(){
		return nodeNumber;
	}
	
	
}
