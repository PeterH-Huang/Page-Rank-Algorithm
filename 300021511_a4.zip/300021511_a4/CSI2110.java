/** To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * 
 * Name: Peter Huang
 * Student Number: 300021511
 * 
 * 
*/

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
//import javafx.util.Pair;

/**
 *
 * @author Administrator
 */
/*
 * 
 * Name: Peter Huang
 * Student Number: 300021511
 * 
 */
public class CSI2110 {
// dampening effect
    private static final double d = 0.85;
//maps will be used to look and search up data


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
		long start = System.nanoTime();
        String edgesFilename = "email-dnc.edges";
        Graph                       graph = readGraph(edgesFilename);
        List<Integer>               nodes = graph.getGraphNodes();
        Map<Integer, List<Integer>> edges = graph.getGraphEdges();
        
        // nodes that will be returned as the result will be stored in an array
        List<Node> returner = new ArrayList<Node>();
        returner = mostInfluentialNodes(graph ,10);
        
        //printing out the nodes
        for(Node i: returner) {
        	System.out.println("Node: "+ i.getNodeNumber()+", Page Rank: "+ i.getPageRank());
        }
        
        System.out.println("Number of nodes in the Graph: " + nodes.size());
		long end = System.nanoTime();
		System.out.println(" the compute time is: "+ (end - start)+" nanoseconds.");
    }
    
    //finds the node with the highest page rank
    public static Node highestPageRank(List<Node> nl){
    	// for now the highest node will be the first node in the list as default
    	Node largest = nl.get(0);
    	//as we go down the node list we will search for nodes with higher page ranks
    	for (Node n: nl) {
    		//if there is one, that node will now become the largest node
    		if(n.getPageRank()>largest.getPageRank()){
                largest = n;
    		}
    	}
    	return largest;
    }
    
    
    //calculates the page rank of every node in the graph
    public static List<Node> pageRankCalc (Graph graph){
          Map<Integer,List<Integer>> edges = graph.getGraphEdges();
          List<Integer> graphNodes = graph.getGraphNodes();
          // instead of integers, this list contains all nodes that will have page ranks
          List<Node> trueGraphNodes = new ArrayList<Node>();
          
          for(Integer n: graphNodes){
              Node node2Add = new Node(n);
              trueGraphNodes.add(node2Add);
          }
          //when finding page rank, the more times it loops the more accurate the calculated result is
          //we loop an arbitrary number of 30 times
          for(int i=0; i<30; i++) {
        	  //find which nodes will become a linked node(linked nodes will be needed to calculate page rank) and adds them to the list of linked nodes
        	  for(Node n:trueGraphNodes) {
        		  List<Node> linked = new ArrayList<Node>();
        		  for(Node o: trueGraphNodes) {
        			  if(n.getNodeNumber() != o.getNodeNumber()){
                          List<Integer> linksOutgoing = (edges.get(o.getNodeNumber()));
                          for(Integer d: linksOutgoing){
                              if(d==n.getNodeNumber()){
                            	  linked.add(o);
                              }
                          }
        			  }
        		  }
        		  //calculates the PR(T1)/C(T1) + ... + PR(Tn)/C(Tn) portion of the page rank equation
        		  double prEq2nd = 0;
                  for(Node e: linked){
                	  prEq2nd = prEq2nd + (e.getPageRank())/(edges.get(e.getNodeNumber()).size());
                  }
        		  // calculates the  (1-d) + d ( portion of the page rank equation using the results of the other part to create a temporary page rank
                  n.setPageRank((1-d)+(d*prEq2nd)); 
        	  }
          }

          return trueGraphNodes;
    }
    
    
    //finds the int num most influential nodes(highest page rank)
    public static List<Node> mostInfluentialNodes(Graph graph, int num){
    	//stores the most influential nodes
    	List<Node> mostInfluential = new ArrayList<Node>();
    	// instead of integers, this list contains all nodes that will have page ranks
    	List<Node> nodeList = new ArrayList<Node>();
    	//calculate the page rank of all nodes
    	nodeList = pageRankCalc (graph);
        
    	//take the top num amount of nodes and adds it to the mostInfluential list
    	for(int k = 0; k<num; k++) {
    		Node most = highestPageRank(nodeList);
    		mostInfluential.add(most);
    		nodeList.remove(most);
    	}
    	return mostInfluential;
    }
    
    
   
    
    
    private static Graph readGraph(String edgesFilename) throws FileNotFoundException, IOException {
        System.getProperty("user.dir");
        URL edgesPath = CSI2110.class.getResource(edgesFilename);
        BufferedReader csvReader = new BufferedReader(new FileReader(edgesPath.getFile()));
        String row;
        List<Integer>               nodes = new ArrayList<Integer>();
        Map<Integer, List<Integer>> edges = new HashMap<Integer, List<Integer>>(); 
        
        boolean first = false;
        while ((row = csvReader.readLine()) != null) {
            if (!first) {
                first = true;
                continue;
            }
            
            String[] data = row.split(",");
            
            Integer u = Integer.parseInt(data[0]);
            Integer v = Integer.parseInt(data[1]);
            
            if (!nodes.contains(u)) {
                nodes.add(u);
            }
            if (!nodes.contains(v)) {
                nodes.add(v);
            }
            
            if (!edges.containsKey(u)) {
                // Create a new list of adjacent nodes for the new node u
                List<Integer> l = new ArrayList<Integer>();
                l.add(v);
                edges.put(u, l);
            } else {
                edges.get(u).add(v);
            }
        }
        
        for (Integer node : nodes) {
            if (!edges.containsKey(node)) {
                edges.put(node, new ArrayList<Integer>());
            }
        }
        
        csvReader.close();
        return new Graph(nodes, edges);
    }
    
}
